<template>
  <div class="main">
    <p>飞机</p>
    <el-divider></el-divider>
    <div class="table-head">
      <div class="table-head-context">
        <p class="table-head-title">型号总数</p>
        <div class="table-head-value">
          <span class="table-head-numvalue">157</span>
          <span class="table-head-strvalue">型</span>
        </div>
      </div>
      <div class="table-head-context">
        <p class="table-head-title">数量总数</p>
        <div class="table-head-value">
          <span class="table-head-numvalue">132461</span>
          <span class="table-head-strvalue">架</span>
        </div>
      </div>
      <div class="table-head-context">
        <p class="table-head-title">完好总数</p>
        <div class="table-head-value">
          <span class="table-head-numvalue">111574</span>
          <span class="table-head-strvalue">架</span>
        </div>
      </div>
    </div>
    <div id="myChart" :style="{ width: '300px', height: '300px' }"></div>
    <div id="myChart1" :style="{ width: '300px', height: '300px' }"></div>
    <div id="myChart2" :style="{ width: '300px', height: '300px' }"></div>
  </div>
</template>

<script>
export default {
  name: 'hello',
  data() {
    return {
      msg: 'Welcome to Your Vue.js App'
    };
  },
  mounted() {
    this.drawLine();
  },
  methods: {
    drawLine() {
      // 基于准备好的dom，初始化echarts实例
      let myChart = this.$echarts.init(document.getElementById('myChart'));
      // 绘制图表
      myChart.setOption({
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },

        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'value',
          boundaryGap: [0, 0.01]
        },
        yAxis: {
          type: 'category',
          data: ['歼击机', '轰炸机', '运输机', '无人机', '特种级']
        },
        series: [
          {
            name: '完好率',
            barWidth: 8,
            type: 'bar',
            label: {
              show: true, // 开启显示
              position: 'right', // 在上方显示
              formatter: '{c}%', // 显示百分号
              textStyle: { // 数值样式
                color: 'black', // 字体颜色
                fontSize: 10// 字体大小
              }
            },
            showBackground: true,
            backgroundStyle: {
              color: 'rgba(0, 220, 220, 0.8)'
            },
            data: [62.7, 55.1, 62.7, 17.2, 39.8]
          }
        ]
      });

      // 基于准备好的dom，初始化echarts实例
      let myChart1 = this.$echarts.init(document.getElementById('myChart1'));
      // 绘制图表
      myChart1.setOption({
        // title: { text: '在Vue中使用echarts' },
        tooltip: {},
        xAxis: {
          data: ['衬衫', '羊毛衫', '雪纺衫', '裤子', '高跟鞋', '袜子']
        },
        yAxis: {},
        series: [
          {
            name: '销量',
            type: 'bar',
            data: [5, 20, 36, 10, 10, 20]
          }
        ]
      });

      // 基于准备好的dom，初始化echarts实例
      let myChart2 = this.$echarts.init(document.getElementById('myChart2'));
      // 绘制图表
      myChart2.setOption({
        // title: { text: '在Vue中使用echarts' },
        tooltip: {},
        xAxis: {
          data: ['衬衫', '羊毛衫', '雪纺衫', '裤子', '高跟鞋', '袜子']
        },
        yAxis: {},
        series: [
          {
            name: '销量',
            type: 'bar',
            data: [5, 20, 36, 10, 10, 20]
          }
        ]
      });
    }
  }
};
</script>
<style scoped>
.main {
  display: flex;
  flex-direction: column;
  /* align-items: center; */
  height: 100%;
  width: 100%;
  border:2px solid darkslategray;
  border-radius:10px;
}
.table-head {
  display: flex;
  flex-direction: row;
}
.table-head-context {
  flex: 1;
  display: flex;
  flex-direction: column;
  text-align: center;
  justify-content: center;
}
.table-head-title {
  flex: 1;
  text-align: center;
}
.table-head-value {
  flex: 1;
  display: flex;
  flex-direction: row;
  text-align: center;
  justify-content: center;
}
.table-head-numvalue {
  flex: 1;
  text-align: center;
  justify-content: center;
  margin-left:20px;
}
.table-head-strvalue {
  text-align: center;
  justify-content: flex-end;
}
</style>
